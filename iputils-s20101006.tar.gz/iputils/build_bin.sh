#!/bin/bash

echo "tar iputils-s20101006.tar.bz2"
tar jxvf iputils-s20101006.tar.bz2

echo "patch iputils"
patch -N -p1 -d iputils-s20101006 < iputils-s20101006_mtk.patch

#build iputils
echo "build iputils"
cd iputils-s20101006
make clean
make

echo "strip iputils"

TRIP=${CROSS_COMPILE}strip
${TRIP} arping
${TRIP} ping
${TRIP} tracepath6
${TRIP} traceroute6

echo "copy arping ping tracepath6 traceroute6"
mkdir -p ${TAR_INSTALL_PATH}/netcom/sbin
cp arping ${TAR_INSTALL_PATH}/netcom/sbin/.
cp ping ${TAR_INSTALL_PATH}/netcom/sbin/.
cp traceroute6 ${TAR_INSTALL_PATH}/netcom/sbin/.
cp tracepath6 ${TAR_INSTALL_PATH}/netcom/sbin/.

