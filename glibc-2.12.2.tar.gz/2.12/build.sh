#!/bin/bash
#for vfp_4.5.1_2.6.27_cortex-a9-rhel4 
#host compile server is Ubuntu 12.04.4 
#set autoconf version as 2.68
export PATH="`pwd`/2.68-autoconf/i686/bin:$PATH"
mkdir 2.12.2
mkdir gcc
cp glibc-2.12.2.tar.bz2 2.12.2
cp glibc-2.12.2-cross_hacks-1.patch  2.12.2
cp  glibc-ports-2.12.2.tar.bz2  2.12.2
cp glibc-2.12.2-wchar.patch  2.12.2
tar -xvjf linux-2.6.35.tar.bz2 
export KERNEL_ROOT=`pwd`/2.6.35
make -f Makefile_a9
if [ $? -ne 0 ];then
    echo  "glibc  build fail"
    exit 1
fi

mkdir lib
cp  -Rpf   sysroot/lib/*  lib
mkdir lib/GlibcStatic
cp  -Rpf   sysroot/usr/lib/libc.a  lib/GlibcStatic
cp  -Rpf   sysroot/usr/lib/libm.a  lib/GlibcStatic
cp  -Rpf   sysroot/usr/lib/libpthread.a   lib/GlibcStatic
gibc_tar_file=glibc-2.12.2-vfp-cotexA9-fastmtrace-install.tar.bz2
tar -cjvf ${gibc_tar_file} lib
rm -rf gcc 2.6.35 
