#!/bin/bash

export CC=${CROSS_COMPILE}gcc
export CXX=${CROSS_COMPILE}g++
export AR=${CROSS_COMPILE}ar
export STRIP=${CROSS_COMPILE}strip
export CHOST=${OSS_HOST}

echo "tar dibbler-0.8.0-src.tar.gz"
tar jxvf dibbler-0.8.0.tar.bz2

echo "patch dibbler-client"
patch -N -p1 -d dibbler-0.8.0 < dibbler-0.8.0-src_mtk.patch

#build dibbler-client
echo "build dibbler-client"
cd dibbler-0.8.0
make clean
make client

echo "strip dibbler-client"

${STRIP} dibbler-client

echo "copy dibbler-client"
mkdir -p ${TAR_INSTALL_PATH}/dibbler/sbin
cp dibbler-client ${TAR_INSTALL_PATH}/dibbler/sbin

cd ..

