#!/bin/sh
#Script to build SaWMan by Yan Wang in MediaTek

        INSTALL_TAR_NAME=sawman-1.4.0-toolchain-451-vfp-install.tar.bz2

if [ true ]; then

#	export DFB_DIR=$(pwd)/../../../build/DirectFB/DirectFB-1.2.7
        
        tar -jxvf sawman-1.4.0.tar.bz2
        cd sawman-1.4.0
        export DFB_DIR=$(pwd)/sysroot
#	export INSTALL_DIR=$(pwd)/build/sawman/sawman-1.4.0
        export INSTALL_DIR=${TAR_INSTALL_PATH}
	export CFLAGS="${CFLAGS} -fPIC -g -fexceptions \
	               -I$(pwd)/sysroot/usr/include"

	if [ -e ${DFB_DIR}/lib/libdirectfb.la ]; then
		mv ${DFB_DIR}/lib/libdirectfb.la ${DFB_DIR}/lib/libdirectfb.la_
	fi

	if [ -z ${MAKE}];then
		MAKE="make"
	fi

	${MAKE} DESTDIR=${INSTALL_DIR} install

	MAKE_RET=$?
	if [ $MAKE_RET -ne 0 ]; then

		if test -z "${CROSS_COMPILE}"; then
			CROSS_COMPILE=armv7a-mediatek451_001_vfp-linux-gnueabi-
		fi

		export CC=${CROSS_COMPILE}gcc
		export AR=${CROSS_COMPILE}ar
		export LD=${CROSS_COMPILE}ld
		export RANLIB=${CROSS_COMPILE}ranlib

		export DFB_LIBS="-L${DFB_DIR}/usr/local/lib -ldirectfb -ldirect -lpthread"
		export DFB_CFLAGS="-D_REENTRANT -I${DFB_DIR}/usr/include/directfb-internal \
		                   -I${DFB_DIR}/usr/include/directfb"

		#export PKG_CONFIG_PATH="${DFB_DIR}/lib/pkgconfig"

		${MAKE} clean
		${MAKE} distclean

		./configure \
		--prefix=/usr \
		--enable-debug=no \
	  --host=armv7a-mediatek451_001_vfp-linux-gnueabi

		MAKE_RET=$?
		if [ $MAKE_RET -ne 0 ]
		then
			if [ -e ${DFB_DIR}/lib/libdirectfb.la_ ]; then
				mv ${DFB_DIR}/lib/libdirectfb.la_ ${DFB_DIR}/lib/libdirectfb.la
			fi
			echo -e "\033[40;31mSaWMan Configure Fail...($MAKE_RET)\033[0m"
			exit $MAKE_RET
		fi

		${MAKE} DESTDIR=${INSTALL_DIR} install

		MAKE_RET=$?
		if [ $MAKE_RET -ne 0 ]
		then
			if [ -e ${DFB_DIR}/lib/libdirectfb.la_ ]; then
				mv ${DFB_DIR}/lib/libdirectfb.la_ ${DFB_DIR}/lib/libdirectfb.la
			fi
			echo -e "\033[40;31mSaWMan Build Fail...($MAKE_RET)\033[0m"
			exit $MAKE_RET
		else
			if [ -e ${DFB_DIR}/lib/libdirectfb.la_ ]; then
				mv ${DFB_DIR}/lib/libdirectfb.la_ ${DFB_DIR}/lib/libdirectfb.la
			fi
			echo -e "\033[40;32mSaWMan Build Success\033[0m"
			mkdir -pv build/sawman/usr/include/sawman/
      mkdir -pv build/sawman/lib/directfb-1.2-0/wm/
      cp -rf build/sawman/sawman-1.4.0/usr/include/sawman/sawman.h  build/sawman/usr/include/sawman/   
      cp -rf build/sawman/sawman-1.4.0/usr/include/sawman/sawman_types.h  build/sawman/usr/include/sawman/   
      cp -rf build/sawman/sawman-1.4.0/usr/lib/libsawman-1.4.so.0  build/sawman/lib/
      cp -rf build/sawman/sawman-1.4.0/usr/lib/libsawman-1.4.so.0.0.0  build/sawman/lib/
      cp -rf build/sawman/sawman-1.4.0/usr/lib/libsawman.so  build/sawman/lib/    
      cp -rf build/sawman/sawman-1.4.0/wm/libdirectfbwm_sawman.so  build/sawman/lib/directfb-1.2-0/wm/     
      
      cd build/sawman/   
      tar -cvjf ./${INSTALL_TAR_NAME} ./usr ./lib
      rm -rf ./lib
      rm -rf ./usr
      cd -
			exit $MAKE_RET
		fi

	else
		if [ -e ${DFB_DIR}/lib/libdirectfb.la_ ]; then
			mv ${DFB_DIR}/lib/libdirectfb.la_ ${DFB_DIR}/lib/libdirectfb.la
		fi
		echo -e "\033[40;32mSaWMan Build Success\033[0m"
		echo "tar sawman-1.4.0-install.tar.bz2..."
	  mkdir -pv build/sawman/usr/include/sawman/
    mkdir -pv build/sawman/lib/directfb-1.2-0/wm/
    cp -rf build/sawman/sawman-1.4.0/usr/include/sawman/sawman.h  build/sawman/usr/include/sawman/   
    cp -rf build/sawman/sawman-1.4.0/usr/include/sawman/sawman_types.h  build/sawman/usr/include/sawman/   
    cp -rf build/sawman/sawman-1.4.0/usr/lib/libsawman-1.4.so.0  build/sawman/lib/
    cp -rf build/sawman/sawman-1.4.0/usr/lib/libsawman-1.4.so.0.0.0  build/sawman/lib/
    cp -rf build/sawman/sawman-1.4.0/usr/lib/libsawman.so  build/sawman/lib/    
    cp -rf build/sawman/sawman-1.4.0/wm/libdirectfbwm_sawman.so  build/sawman/lib/directfb-1.2-0/wm/      
    cd build/sawman/  
    tar -cvjf ./${INSTALL_TAR_NAME} ./usr ./lib
    rm -rf ./lib
    rm -rf ./usr
#   mv -f  ./${INSTALL_TAR_NAME}  library/sawman/
#   cd -
		exit 0
	fi

else
	echo -e "\033[40;31mDirectFB is not supported!\033[0m"
	echo -e "\033[40;31mNo need to build SaWMan!\033[0m"
	exit 0
fi
