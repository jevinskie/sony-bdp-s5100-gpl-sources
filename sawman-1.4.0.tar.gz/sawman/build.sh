#!/bin/bash

if [ -z ${CROSS_COMPILE} ]; then
    export CROSS_COMPILE="armv6z-mediatek451_001_vfp-linux-gnueabi-"
fi

if [ -z ${OSS_HOST} ]; then
    export OSS_HOST="armv6z-mediatek451_001_vfp-linux-gnueabi"
fi

if [ -z ${TAR_INSTALL_PATH} ]; then
    export TAR_INSTALL_PATH="$(pwd)/library"
fi

export CC=${CROSS_COMPILE}gcc

source ./build_bin.sh
