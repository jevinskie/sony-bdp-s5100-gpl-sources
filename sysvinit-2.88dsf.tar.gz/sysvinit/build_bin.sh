#!/bin/bash

oss_name=sysvinit
sysvinit_version=2.88dsf

rm -rf sysvinit-$sysvinit_version
dir="sysvinit-$sysvinit_version" 
  
mkdir $dir  
tar -jxvf sysvinit-2.88dsf.tar.bz2 -C ./$dir
cd $dir/sysvinit-2.88dsf
make
if [$? -ne 0 ]; then
    exit 1
fi
make install ROOT=${TAR_INSTALL_PATH}/sysvinit
