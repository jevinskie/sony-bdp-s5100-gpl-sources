#!/bin/bash
oss_name=procps
oss_version=3.2.8

export CC=${CROSS_COMPILE}gcc
export CXX=${CROSS_COMPILE}g++
export AR=${CROSS_COMPILE}ar
export RANLIB=${CROSS_COMPILE}ranlib
export LD=${CROSS_COMPILE}ld
export STRIP=${CROSS_COMPILE}strip

rm -rf ncurses-5.7
tar zxvf ncurses-5.7.tar.gz
procps_path=`pwd`
cd ncurses-5.7
./configure --prefix=${TAR_INSTALL_PATH}/procps/ncurses --host=${OSS_HOST} --with-shared
echo "LIBS = " >> src/Makefile 
make 
make install
NCURSES_DIR=${TAR_INSTALL_PATH}/procps/ncurses
cd ${procps_path}
rm -rf procps-${oss_version}
tar zxvf procps-${oss_version}.tar.gz
cd procps-${oss_version}
make CPPFLAGS="-I$NCURSES_DIR/include/ncurses -I$NCURSES_DIR/include" LDFLAGS="-L$NCURSES_DIR/lib"
if [ $? -ne 0 ]; then
    exit  1
fi
mkdir -p ${TAR_INSTALL_PATH}/procps/usr/bin
mkdir -p ${TAR_INSTALL_PATH}/procps/bin
mkdir -p ${TAR_INSTALL_PATH}/procps/lib
mkdir -p ${TAR_INSTALL_PATH}/procps/sbin
mkdir -p ${TAR_INSTALL_PATH}/procps/usr/share/man/man1/
mkdir -p ${TAR_INSTALL_PATH}/procps/usr/share/man/man5/
mkdir -p ${TAR_INSTALL_PATH}/procps/usr/share/man/man8/

make install="install" DESTDIR=${TAR_INSTALL_PATH}/procps install lib64=lib ldconfig=""
