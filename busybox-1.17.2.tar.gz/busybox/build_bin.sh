#!/bin/bash

oss_name=busybox
busybox_version=1.17.2

echo "enter ${oss_name}-${busybox_version} build"

export CC=${CROSS_COMPILE}gcc
export LD=${CROSS_COMPILE}ld
export AR=${CROSS_COMPILE}ar
export STRIP=${CROSS_COMPILE}strip

rm -rf busybox-$busybox_version
dir="busybox-$busybox_version" 

mkdir $dir 
tar jxvf busybox-${busybox_version}.tar.bz2 -C ./$dir
cd $dir/busybox-${busybox_version}

make defconfig
make ARCH=arm
if [ $? -ne 0 ]; then
    exit 1
fi
make install 
cd _install

tar_file=$dir-install.tar.bz2
cp -f ./bin/busybox ./sbin/busybox
tar -cjf $tar_file ./sbin/busybox
mkdir -p ${TAR_INSTALL_PATH}/busybox
cp -f $tar_file ${TAR_INSTALL_PATH}/busybox
