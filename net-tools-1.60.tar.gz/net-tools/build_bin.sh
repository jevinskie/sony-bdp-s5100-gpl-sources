#!/bin/bash

#export path for arm-linux gcc



tar -jxv -f net-tools-1.60.tar.bz2

echo "patch"
patch -N -p1 -d net-tools-1.60 < net-tools-1.60_mtk.patch

echo "build udhcpc"
cd net-tools-1.60
make

echo "strip udhcpc"

TRIP=${CROSS_COMPILE}strip
echo ${TRIP}
${TRIP} hostname
${TRIP} ifconfig
${TRIP} route


echo "copy bin"
mkdir -p ${TAR_INSTALL_PATH}/netcom/sbin
cp hostname ${TAR_INSTALL_PATH}/netcom/sbin/.
cp ifconfig ${TAR_INSTALL_PATH}/netcom/sbin/.
cp route ${TAR_INSTALL_PATH}/netcom/sbin/.


