#!/bin/bash

export CC=${CROSS_COMPILE}gcc
export CXX=${CROSS_COMPILE}g++
export LD=${CROSS_COMPILE}ld
export AR=${CROSS_COMPILE}ar
export AS=${CROSS_COMPILE}as
export RANLIB=${CROSS_COMPILE}ranlib
export STRIP=${CROSS_COMPILE}strip

tar -jxvf ffmpeg-0.5.15.tar.bz2
cd ffmpeg-0.5.15

./configure --prefix=${TAR_INSTALL_PATH} --enable-cross-compile --cross-prefix=${CROSS_COMPILE} --disable-static --enable-shared --arch=arm

make
if [ 0 -ne $? ]; then
    echo "make ffmpeg failed"
    exit 1
fi

make install

