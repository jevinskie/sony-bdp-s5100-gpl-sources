#!/bin/bash
echo "enter freetype-2.3.9"
export CC=${CROSS_COMPILE}gcc

rm -rf freetype-2.3.9
tar -xvf freetype-2.3.9.tar.gz
cd freetype-2.3.9/
make clean
./configure --prefix=${TAR_INSTALL_PATH}/freetype/usr --host=${OSS_HOST} --build=x86_64 --enable-shared --with-python="no"
make -j 4
make install
cd ${TAR_INSTALL_PATH}/freetype/
tar_file=freetype-2.3.9-${TAR_NAME_KEY_WORD}-install.tar.bz2
tar -cjf $tar_file usr/
