#! /bin/sh

rm -rf jpeg-7
tar zxvf jpeg-7.tar.gz

cd jpeg-7

make clean
make distclean

oss_name=jpeg
oss_version=7

make

MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then

./configure --host=${OSS_HOST} --target=${OSS_HOST} --prefix=${TAR_INSTALL_PATH}/jpeg/usr 

make
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBJPEG Build Fail....($MAKE_RET)"
    exit $MAKE_RET
else
    echo "LIBJPEG Build OK..."
fi

make install
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBJPEG Install Fail....($MAKE_RET)"
    exit $MAKE_RET
else
   cd ${TAR_INSTALL_PATH}/jpeg
   echo `pwd`
   tar -jcvf ${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2 ./usr      
   echo "LIBJPEG Install OK..."
fi

else
    echo "LIBJPEG existed! no need to build..."
fi

exit 0 
