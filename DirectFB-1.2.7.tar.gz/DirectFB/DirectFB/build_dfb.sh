#!/bin/sh

#Please notes this script will copy to from_real_branch folder

mkdir -p ./sysroot/usr/include
mkdir -p ./sysroot/usr/lib

export oss_name="DirectFB"
export libpng_oss_version=1.2.50

export DFB_DIR=${TAR_INSTALL_PATH}/build/DirectFB/DirectFB-${oss_version}

fusiontar="`ls ${TAR_INSTALL_PATH}/linux-fusion/*-install.tar.bz2`"
fusiontar=${fusiontar##*/}
export fusiontar=${fusiontar%-*}
export fusiontar1=${fusiontar// }
tar -jxvf  ${TAR_INSTALL_PATH}/linux-fusion/${fusiontar1}-install.tar.bz2 -C ./sysroot

#Define tar name 
INSTALL_TAR_NAME=${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2

 
#mkdir and define DirectFB install path
mkdir -p ${TAR_INSTALL_PATH}/build/DirectFB/DirectFB-${oss_version}
export DEST_DIR=${TAR_INSTALL_PATH}/build/DirectFB/DirectFB-${oss_version}

#check all dependent packages
file_count=`ls ${TAR_INSTALL_PATH}/zlib/usr/lib | wc -l`
echo "file_count="${file_count}
if [ ${file_count} -gt "0" ];then
	echo "Has zlib"
else
	echo "no zlib or zlib build fail, please check it"
	exit 0 
fi

file_count=`ls ${TAR_INSTALL_PATH}/freetype/usr/lib | wc -l`
echo "file_count="${file_count}
if [ "$file_count" -gt "0" ];then
	echo "Has freetype"
else
	
	echo "no freetype or freetype build fail, please check it"
	exit 0 
fi

file_count=`ls ${TAR_INSTALL_PATH}/libpng/libpng-${libpng_oss_version}/usr/lib | wc -l`
echo "file_count="${file_count}
if [ "$file_count" -gt "0" ];then
	echo "Has libpng"
else
	echo "no libpng or libpng build fail, please check it"
	exit 0 
fi

file_count=`ls ${TAR_INSTALL_PATH}/jpeg/usr/lib | wc -l`
echo "file_count="${file_count}
if [ "$file_count" -gt "0" ];then
	echo "Has jpeg"
else
	
	echo "no jpeg or jpeg build fail, please check it"
	exit 0 
fi

#define freetype header path and lib name
export FREETYPE_CFLAGS="-I${TAR_INSTALL_PATH}/freetype/usr/include"	
export FREETYPE_LIBS="-lfreetype"

#define libs and headers path for zlib, freetype, libpng, jpeg, fusion, driver, system
export LDFLAGS="-L${TAR_INSTALL_PATH}/zlib/usr/lib -lz -L${TAR_INSTALL_PATH}/freetype/usr/lib -L${TAR_INSTALL_PATH}/libpng/libpng-${libpng_oss_version}/usr/lib -L${TAR_INSTALL_PATH}/jpeg/usr/lib $LDFLAGS"              	                
export CFLAGS="$CFLAGS -rdynamic -fPIC -g -fexceptions  \
		-DCONFIG_CHIP_VER_CURR=8560 \
		-DCONFIG_CHIP_VER_MT8555=8555 \
		-DCONFIG_CHIP_VER_MT8560=8560 \
                -DCONFIG_CHIP_VER_MT8580=8580 \
		-DCONFIG_CHIP_VER_MT8561=8561 \
                -DCONIFG_MTK_DFB_DYNAMIC_LOAD_FUSION=0 \
                -I${TAR_INSTALL_PATH}/freetype/usr/include/freetype2 \
								-I${TAR_INSTALL_PATH}/libpng/libpng-${libpng_oss_version}/usr/include \
								-I${TAR_INSTALL_PATH}/zlib/usr/include \
								-I${TAR_INSTALL_PATH}/jpeg/usr/include \
                -I$(pwd)/systems/mtk \
                -I$(pwd)/sysroot/usr/include "
	
make clean
make distclean

if test -z "${CROSS_COMPILE}"; then
	echo "no CROSS_COMPILE"
fi
	
echo "DirectFB Dynamic Library Will Build" 

#start DirectFB config
	./configure \
	--prefix=/usr \
	--exec-prefix=/ \
	--host=${OSS_HOST} \
	--enable-debug=no \
	--enable-multi \
	--enable-x11=no \
	--enable-osx=no \
	--enable-voodoo=no \
	--enable-mmx=no \
	--enable-sse=no \
	--enable-devmem=no \
	--enable-fbdev=no \
	--enable-mtk \
	--enable-jpeg \
	--enable-png \
	--enable-gif \
	--enable-freetype \
	--enable-video4linux=no \
	--with-gfxdrivers=mt85 \
	--with-tools \
	--with-inputdrivers=lirc,keyboard,ps2mouse \
	--without-smooth-scaling

#start DirectFB build and install
make -j64
make DESTDIR=${DEST_DIR} install

#check build result
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
   echo "DirectFB Dynamic Library Build Fail......($MAKE_RET)"
   exit $MAKE_RET
else
    echo "DirectFB Dynamic Library Build Success"
fi

#mtk40438 add
STATIC_LIBRARY=YES

if [ "$1" = "-dynamic" ]; then
    shift
    echo "Only build dynamic library!!"
    STATIC_LIBRARY=
fi

if [ -n "${STATIC_LIBRARY}" ]; then

#mkdir static library build path and define the path 
mkdir -p ${TAR_INSTALL_PATH}/build/DirectFB/DirectFB-${oss_version}_static
export DEST_DIR_STATIC=${TAR_INSTALL_PATH}/build/DirectFB/DirectFB-${oss_version}_static

#define the headers and libs path for freetype, libpng, jpeg, fusion, system, driver
export FREETYPE_CFLAGS="-I${TAR_INSTALL_PATH}/freetype/usr/include"	
export FREETYPE_LIBS="-lfreetype"
export LDFLAGS="-L${TAR_INSTALL_PATH}/zlib/usr/lib -lz -L${TAR_INSTALL_PATH}/freetype/usr/lib -L${TAR_INSTALL_PATH}/libpng/libpng-${libpng_oss_version}/usr/lib -L${TAR_INSTALL_PATH}/jpeg/usr/lib $LDFLAGS"
export CFLAGS="$CFLAGS -rdynamic -fPIC -g -fexceptions -DMTK_DFB_STATIC \
		-DCONFIG_CHIP_VER_CURR=8560 \
                -DCONFIG_CHIP_VER_MT8555=8555 \
                -DCONFIG_CHIP_VER_MT8560=8560 \
                -DCONFIG_CHIP_VER_MT8580=8580 \
		-DCONFIG_CHIP_VER_MT8561=8561 \
                -DCONIFG_MTK_DFB_DYNAMIC_LOAD_FUSION=0 \
                -I${TAR_INSTALL_PATH}/freetype/usr/include/freetype/usr/include/freetype2 \
		-I${TAR_INSTALL_PATH}/libpng/libpng-${libpng_oss_version}/usr/include \
		-I${TAR_INSTALL_PATH}/zlib/usr/include \
		-I${TAR_INSTALL_PATH}/jpeg/usr/include \
                -I$(pwd)/systems/mtk \
                -I$(pwd)/sysroot/usr/include "

make clean
make distclean

if test -z "${CROSS_COMPILE}"; then
	echo "No CROSS_COMPILE definition"
	exit 0
fi

#start DirectFB Static Library config
echo "DirectFB Static Library Will Build"
	./configure \
	--prefix=/usr \
	--exec-prefix=/ \
	--host=${OSS_HOST} \
	--enable-debug=no \
	--enable-multi \
	--enable-x11=no \
	--enable-osx=no \
	--enable-voodoo=no \
	--enable-mmx=no \
	--enable-sse=no \
	--enable-devmem=no \
	--enable-fbdev=no \
	--enable-mtk \
	--enable-jpeg \
	--enable-png \
	--enable-gif \
	--enable-freetype \
	--enable-video4linux=no \
	--with-gfxdrivers=mt85 \
	--with-tools \
	--with-inputdrivers=lirc,keyboard,ps2mouse \
	--enable-static \
	--without-smooth-scaling

#start build DirectFB Static Library 
	make -j64
	make DESTDIR=${DEST_DIR_STATIC} install

#check build result
	MAKE_RET=$?
	if [ $MAKE_RET -ne 0 ]; then
	   echo "DirectFB Static Library Build Fail......($MAKE_RET)"
	   exit $MAKE_RET
	else
	    echo "DirectFB Static Library Build Success"
	fi
fi

if [ -n "${STATIC_LIBRARY}" ]; then
  echo "tar dynamic and static library files to DirectFB-1.2.7-xx-install.tar.bz2..."
   
  #cd to build folder and tar
  cd ${DEST_DIR}
  ln -s libdirect-1.2.so.0.7.0 ./lib/libdirect-1.2.so.0
  ln -s libdirect-1.2.so.0.7.0 ./lib/libdirect.so
	
  ln -s libdirectfb-1.2.so.0.7.0 ./lib/libdirectfb-1.2.so.0
  ln -s libdirectfb-1.2.so.0.7.0 ./lib/libdirectfb.so
	
  ln -s libfusion-1.2.so.0.7.0 ./lib/libfusion-1.2.so.0
  ln -s libfusion-1.2.so.0.7.0 ./lib/libfusion.so
  cd -
	
#find .a and .o and copy them from {DEST_DIR_STATIC} to ${DEST_DIR}
  cd ${DEST_DIR_STATIC}

  LOCAL_FILE=file.log
  rm ${LOCAL_FILE} -fr
  find ./* -name *.a > ${LOCAL_FILE}
  find ./* -name *.o >> ${LOCAL_FILE}
  cd -
 
  cp ${DEST_DIR_STATIC}/file.log .
    
  while read -r temp; do
	cp ${DEST_DIR_STATIC}/${temp} ${DEST_DIR}/${temp}		 
  done < ${LOCAL_FILE}

 cd ${DEST_DIR}
 	mkdir ${TAR_INSTALL_PATH}/DirectFB
   tar -jcvf ${TAR_INSTALL_PATH}/DirectFB/${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2 ./
   cd -
   echo "DirectFB Install OK..."

else
####	
    echo "tar dynamic library files to DirectFB-1.2.7-xx-install.tar.bz2..."
  
    #cd to build folder and tar
    cd ${DEST_DIR}
   echo `pwd`
   #rm -rf ${TAR_INSTALL_PATH}/DirectFB/${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2
  ln -s libdirect-1.2.so.0.7.0 ./lib/libdirect-1.2.so.0
	ln -s libdirect-1.2.so.0.7.0 ./lib/libdirect.so
	
	ln -s libdirectfb-1.2.so.0.7.0 ./lib/libdirectfb-1.2.so.0
	ln -s libdirectfb-1.2.so.0.7.0 ./lib/libdirectfb.so
	
	ln -s libfusion-1.2.so.0.7.0 ./lib/libfusion-1.2.so.0
	ln -s libfusion-1.2.so.0.7.0 ./lib/libfusion.so
	mkdir ${TAR_INSTALL_PATH}/DirectFB
   tar -jcvf ${TAR_INSTALL_PATH}/DirectFB/${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2 ./
   cd -
   echo "DirectFB Install OK..."
    

   
####    
	exit 0
fi
