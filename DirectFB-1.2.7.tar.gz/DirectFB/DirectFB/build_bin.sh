#!/bin/sh
export PATH="${TAR_INSTALL_PATH}/libpng/libpng-1.2.50/usr/bin:${PATH}"
export oss_version=1.2.7

tar -xjvf DirectFB-1.2.7.tar.bz2

mkdir -p ./from_real_branch
rm -rf ./from_real_branch/*
cp -rf DirectFB-${oss_version} ./from_real_branch/
cp -f ./build_dfb.sh ./from_real_branch/DirectFB-${oss_version}
cd from_real_branch/DirectFB-${oss_version}
sh build_dfb.sh 2>&1 | tee make.log
cd -
mv ${TAR_INSTALL_PATH}/build/* ${TAR_INSTALL_PATH}/DirectFB/
