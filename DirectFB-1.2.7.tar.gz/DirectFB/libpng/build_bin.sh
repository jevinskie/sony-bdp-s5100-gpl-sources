#! /bin/sh

oss_version=1.2.50

rm -rf libpng-1.2.50
tar -zxvf libpng-1.2.50.tar.gz

oss_name=libpng

cd libpng-${oss_version}

make clean
make distclean

chmod 777 configure

export LDFLAGS="$LDFLAGS -L${TAR_INSTALL_PATH}/zlib/usr/lib -L${TAR_INSTALL_PATH}/freetype/usr/lib"

export CFLAGS="$CFLAGS -I${TAR_INSTALL_PATH}/zlib/usr/include -I${TAR_INSTALL_PATH}/freetype/usr/include"
export CPPFLAGS="$CPPFLAGS -I${TAR_INSTALL_PATH}/zlib/usr/include "

export CC=${CROSS_COMPILE}gcc
export LD=${CROSS_COMPILE}ld
./configure --host=${OSS_HOST} --target=${OSS_HOST} --prefix=${TAR_INSTALL_PATH}/libpng/libpng-${oss_version}/usr

make
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBPNG Build Fail....($MAKE_RET)"
    exit $MAKE_RET
else
    echo "LIBPNG Build OK..."
fi
make install
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBPNG Install Fail....($MAKE_RET)"
    exit $MAKE_RET
else
   cd ${TAR_INSTALL_PATH}/libpng
   rm -rf ${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2
   cd libpng-${oss_version}/
   tar -jcvf ../${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2 ./usr
   echo "LIBPNG Install OK..."
fi
exit 0 
