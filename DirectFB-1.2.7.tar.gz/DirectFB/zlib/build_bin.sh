#! /bin/sh

rm -rf zlib-1.2.3
tar zxvf zlib-1.2.3.tar.gz

cd zlib-1.2.3

make clean
make distclean

oss_name=zlib
oss_version=1.2.3

export CC=${CROSS_COMPILE}gcc
export LD=${CROSS_COMPILE}ld
./configure --prefix=${TAR_INSTALL_PATH}/zlib/usr

make
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBZ Build Fail....($MAKE_RET)"
    exit $MAKE_RET
else
    echo "LIBZ Build OK..."
fi

make install

./configure --prefix=${TAR_INSTALL_PATH}/zlib/usr --shared


make
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBZ Build Fail....($MAKE_RET)"
    exit $MAKE_RET
else
    echo "LIBZ Build OK..."
fi

make install
MAKE_RET=$?
if [ $MAKE_RET -ne 0 ]; then
    echo "LIBZ Install Fail....($MAKE_RET)"
    exit $MAKE_RET
else
   cd ${TAR_INSTALL_PATH}/zlib
   echo `pwd`
   tar -jcvf ${oss_name}-${oss_version}-${TAR_NAME_KEY_WORD}-install.tar.bz2 ./usr
   echo "LIBZ Install OK..."
fi

exit 0 
