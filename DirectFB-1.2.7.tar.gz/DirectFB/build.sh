#!/bin/bash

if [ -z ${CROSS_COMPILE} ]; then
    export CROSS_COMPILE="armv6z-mediatek451_001_vfp-linux-gnueabi-"
fi

if [ -z ${OSS_HOST} ]; then
    export OSS_HOST="armv6z-mediatek451_001_vfp-linux-gnueabi"
fi

if [ -z ${TAR_INSTALL_PATH} ]; then
    export TAR_INSTALL_PATH="$(pwd)/library"
fi

export CC=${CROSS_COMPILE}gcc

cd zlib
./build_bin.sh
cd ../freetype
./build_bin.sh
cd ../libpng
./build_bin.sh
cd ../jpeg
./build_bin.sh
cd ../linux-fusion
./build_bin.sh
cd ../DirectFB
./build_bin.sh
