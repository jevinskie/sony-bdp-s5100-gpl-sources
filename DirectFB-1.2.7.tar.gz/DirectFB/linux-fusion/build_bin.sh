#!/bin/sh

tar -jxvf linux-fusion-8.2.0.tar.bz2
cd linux-fusion-8.2.0

export KERNELRELEASE=2.6.35
export DEST_DIR=${TAR_INSTALL_PATH}/linux-fusion/linux-fusion-8.2.0

make V=1 CROSS_COMPILE=${CROSS_COMPILE}
MAKE_RET=$?
if [ "$?" -eq 0 ];then
    if [ ! -e ${DEST_DIR} ]; then
        mkdir -p ${DEST_DIR}
    fi
    mkdir -p ${DEST_DIR}/lib/modules/2.6.35/BDP
    mkdir -p ${DEST_DIR}/usr/
    cp -f linux/drivers/char/fusion/fusion.ko ${DEST_DIR}/lib/modules/2.6.35/BDP
    cp -frp linux/include/ ${DEST_DIR}/usr/
    cd ${DEST_DIR}
    tar -cvjf ../linux-fusion-8.2.0-${TAR_NAME_KEY_WORD}-install.tar.bz2 ./
    cd -
    echo "Fusion Build Success"
    exit $MAKE_RET
else
    echo "Fusion Build Fail...($MAKE_RET)"
    exit $MAKE_RET
fi
