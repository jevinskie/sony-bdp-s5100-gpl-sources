#!/bin/bash
echo "ztm enter e2fsprogs"
export CC=${CROSS_COMPILE}gcc

rm -rf ./e2fsprogs*/
tar -jxvf e2fsprogs-1.41.11.tar.bz2
cd e2fsprogs-1.41.11/
./configure --host=${OSS_HOST} LDFLAGS=-static --prefix=${TAR_INSTALL_PATH}/e2fsprogs
make
make install
