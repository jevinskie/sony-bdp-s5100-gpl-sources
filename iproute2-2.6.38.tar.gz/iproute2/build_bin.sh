#!/bin/bash

export CC=${CROSS_COMPILE}gcc
export CXX=${CROSS_COMPILE}g++
export LD=${CROSS_COMPILE}ld
export STRIP=${CROSS_COMPILE}strip

tar -zxvf db-4.8.30.tar.gz

cd db-4.8.30/build_unix
../dist/configure --host=${OSS_HOST} --prefix=`pwd`/../../libdb --enable-compat185
make
make install

cd ../../
tar -jxv -f iproute2-2.6.38.tar.bz2
patch -N -p1 -d iproute2-2.6.38 < iproute2-2.6.38_mtk.patch
cd iproute2-2.6.38
make clean
make

${STRIP} ip/ip

mkdir -p ${TAR_INSTALL_PATH}/netcom/sbin
cp ip/ip ${TAR_INSTALL_PATH}/netcom/sbin/
