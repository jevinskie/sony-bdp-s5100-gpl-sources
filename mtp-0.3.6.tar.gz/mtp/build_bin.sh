#! /bin/sh

LIBMTP=mtp-0.3.6
dir="$LIBMTP"    

rm -rf $LIBMTP
tar zxvf mtp-0.3.6.tar.gz

cd $LIBMTP

sh build.sh

cp include/* $TAR_INSTALL_PATH/mtp/$LIBMTP/install/include

cd $TAR_INSTALL_PATH/mtp/$LIBMTP

mv install usr
