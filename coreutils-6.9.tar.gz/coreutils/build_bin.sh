#!/bin/bash

oss_name=coreutils
coreutils_version=6.9

echo "enter ${oss_name}-${oss_version} build"

tar -zxvf coreutils-6.9_patch.tar.gz
 
rm -rf coreutils-$coreutils_version
dir="coreutils-$coreutils_version" 
 
mkdir $dir  
tar -jxvf coreutils-6.9.tar.bz2 -C ./$dir 
cp -rf coreutils-6.9_patch/*   ./$dir/coreutils-6.9/
cd $dir/coreutils-6.9/
./configure  --host=${OSS_HOST} --prefix=${TAR_INSTALL_PATH}/coreutils
make
if [ $? -ne 0 ]; then
    exit 1
fi
make install

cd ${TAR_INSTALL_PATH}/coreutils
mkdir usr usr/sbin usr/bin
rm -f share/info/dir
mv share -t usr
mv bin/chroot usr/sbin/
mv bin/[ bin/du bin/head bin/expr bin/tee bin/test bin/tr bin/wc bin/md5sum usr/bin
tar_file=$dir-install.tar.bz2
tar -cjf $tar_file ./usr ./bin

