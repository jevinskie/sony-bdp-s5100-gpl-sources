#!/bin/bash

if [ -z ${CROSS_COMPILE} ]; then
    export CROSS_COMPILE="armv6z-mediatek451_001_vfp-linux-gnueabi-"
fi

if [ -z ${OSS_HOST} ]; then
    export OSS_HOST="armv6z-mediatek451_001_vfp-linux-gnueabi"
fi

if [ -z ${TAR_INSTALL_PATH} ]; then
    export TAR_INSTALL_PATH="$(pwd)/library"
fi

export CC="${CROSS_COMPILE}gcc -fPIC"
export LD=${CROSS_COMPILE}ld
export AR=${CROSS_COMPILE}ar
export AS=${CROSS_COMPILE}as
export CXX="${CROSS_COMPILE}g++ -fPIC"
export RANLIB=${CROSS_COMPILE}ranlib
export STRIP=${CROSS_COMPILE}strip

tar -jxvf JavaScriptCore.tar.bz2
cd JavaScriptCore
cmake .
make
if [ 0 -ne $? ]; then
    echo "make JavaScriptCore failed"
    exit 1
fi

mkdir -p ${TAR_INSTALL_PATH}/lib
cp Source/JavaScriptCore/libJavaScriptCore.a ${TAR_INSTALL_PATH}/lib
cd ${TAR_INSTALL_PATH}/lib
ar -x libJavaScriptCore.a
$CXX *.o -o libJavaScriptCore.so -shared
rm *.o
rm *.a


