#!/bin/bash
tar -zxvf lzo-2.06.tar.gz
tar -zxvf zlib-1.2.3.tar.gz
tar -xvf mtd-utils-1.2.0.tar.bz2

cd zlib-1.2.3
chmod 0777 configure
./configure --shared --prefix=${TAR_INSTALL_PATH}/zlib/zlib-1.2.3/out && make clean &&  make -j8 && make install
cd ..
rm -rf zlib-1.2.3

cd lzo-2.06
chmod 0777 configure
./configure --host=${OSS_HOST} --prefix=${TAR_INSTALL_PATH}/lzo/lzo-2.06/out && make clean &&  make -j8 && make install
cd ..
rm -rf lzo-2.06

rm -rf ${TAR_INSTALL_PATH}/mtd-utils/mtd-utils-1.2.0
mv mtd-utils-1.2.0/ ${TAR_INSTALL_PATH}/mtd-utils

cd ${TAR_INSTALL_PATH}/mtd-utils
make  CROSS=${CROSS_COMPILE} BUILDDIR=${TAR_INSTALL_PATH}/mtd-utils DESTDIR=${TAR_INSTALL_PATH}/mtd-utils/out WITHOUT_XATTR=1
if [ $? -ne 0 ];then
   echo "mtd-utils build fail"
   exit 1
fi   
mkdir sbin
mv flash_erase sbin/
mv flash_eraseall sbin/
mv ubi-utils/new-utils/ubimkvol sbin/
mv ubi-utils/new-utils/ubinfo sbin/
mv ubi-utils/new-utils/ubirmvol sbin/
mv ubi-utils/new-utils/ubiattach sbin/
mv ubi-utils/new-utils/ubinize sbin/
mv ubi-utils/new-utils/ubidetach sbin/
mv ubi-utils/new-utils/ubiformat sbin/
mv sbin ${TAR_INSTALL_PATH}
cd ${TAR_INSTALL_PATH}
rm -rf ./mtd-utils/*
mv sbin mtd-utils




