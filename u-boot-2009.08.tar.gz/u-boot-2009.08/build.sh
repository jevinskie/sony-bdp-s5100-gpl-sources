#!/bin/bash

if [ -z ${CROSS_COMPILE} ]; then
    export CROSS_COMPILE="armv7a-mediatek451_001_vfp-linux-gnueabi-"
fi

if [ -z ${OSS_HOST} ]; then
    export OSS_HOST="armv7a-mediatek451_001_vfp-linux-gnueabi"
fi

if [ -z ${TAR_INSTALL_PATH} ]; then
    export TAR_INSTALL_PATH="$(pwd)/library"
fi

export CC=${CROSS_COMPILE}gcc

tar -jxvf u-boot-2009.08.tar.bz2

cd u-boot-2009.08

make -f mtk.mk SHELL=/bin/bash
